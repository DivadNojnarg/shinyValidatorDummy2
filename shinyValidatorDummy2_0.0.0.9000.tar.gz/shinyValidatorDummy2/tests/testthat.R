library(testthat)
library(shinyValidatorDummy2)

test_check("shinyValidatorDummy2")
